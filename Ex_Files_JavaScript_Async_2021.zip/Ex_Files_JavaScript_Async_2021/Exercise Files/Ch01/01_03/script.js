console.log("Hi!");

setTimeout(function() {
    console.log("Asynchronous result");
}, 5000);

console.log("Synchronous result.");
